


<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html>
    <head>
    <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title></title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="<?php echo asset('css/style.css')?>" type="text/css">
        <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>
<body>
<div class="container">
    <h1 class="text-center">Formulario de Contacto</h1>
    <form action="<?php echo e(route('contacta.store')); ?>" method="POST" style="background-image:url(<?php echo e(url('img/fondo4.jpg')); ?>); background-size:cover" class="card p-3 text-center text-white container_gris">
        <?php echo e(csrf_field()); ?>


        <div class="form-group row">
            <label for="nombre" class="col-md-4 col-form-label text-md-right">Nombre</label>

            <div class="col-md-6">
                <input
                    id="nombre"
                    type="text"
                    class="form-control"
                    name="nombre"
                    required="required"
                    autofocus="autofocus">

            </div>
        </div>
        <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p><strong><?php echo e($message); ?></strong>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <div class="form-group row">
            <label for="email" class="col-md-4 col-form-label text-md-right">E-Mail</label>

            <div class="col-md-6">
                <input
                    id="email"
                    type="text"
                    class="form-control"
                    name="email"
                    required="required"
                    autofocus="autofocus">
            </div>
        </div>
         <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p><strong><?php echo e($message); ?></strong>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        
        <div class="form-group row">
            <label for="mensaje" class="col-md-4 col-form-label text-md-right">Mensaje</label>
            <div class="col-md-6">
    <textarea class="form-control" name="mensaje" rows="3"></textarea>
            </div>
        </div>

        <div class="form-group row mb-0">
            <div class="col-md-6 offset-md-4">
                <button type="submit" class="btn btn-primary">
                    Enviar Mensaje
                </button>
            </div>
        </div>
        <?php $__errorArgs = ['mensaje'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p><strong><?php echo e($message); ?></strong>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        
    </form>
    
    <!-- para redirigir 
    <?php if(session('info')): ?>
        <script>
            alert("<?php echo e(session('info')); ?>");
        </script>
    <?php endif; ?> -->
</div>
</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\biblioW\resources\views/formu.blade.php ENDPATH**/ ?>