

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="text-center">
            Catalogo de libros
            <hr>
            <h3><a href="<?php echo e(url('/registroLibros/create')); ?>">Añadir Libro</a></h3>
            <h3><a href="<?php echo e(url('/listaLibros/index')); ?>">Lista Libro</a></h3>
        </div>

        <hr>

        <div class="d-flex justify-content-between flex-wrap ">
            <?php $__currentLoopData = $libros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $libro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($libro->habilitado): ?>
                    <div class="card mt-3 bg-warning" style="width: 18rem;">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($libro->titulo); ?></h5>
                            <h6 class="card-subtitle mb-2 text-muted"><?php echo e($libro->autor); ?></h6>
                            <p class="card-text"><?php echo e($libro->descripcion); ?></p>
                            <label> <?php echo e($libro->genero); ?></label>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\danny\Desktop\ProyectoDay\08-11-2020\biblionet\resources\views/home.blade.php ENDPATH**/ ?>