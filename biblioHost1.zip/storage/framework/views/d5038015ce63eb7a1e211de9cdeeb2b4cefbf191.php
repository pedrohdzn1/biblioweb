<!DOCTYPE html>

<html>
    <head>
        <meta charset="utf-8">
        <title><?php echo $__env->yieldContent('title'. 'Default'); ?> | BIBLIOWEB</title>
        <link rel="stylesheet" href="<?php echo e(asset('plugins/bootstrap/css/bootstrap.css')); ?>">
    </head>
    <body>
            <section>
            <?php echo $__env->yieldContent('content'); ?>
            </section>
                
    </body>
</html><?php /**PATH C:\Users\danny\Desktop\ProyectoDay\08-11-2020\biblionet\resources\views/admin/template/main.blade.php ENDPATH**/ ?>